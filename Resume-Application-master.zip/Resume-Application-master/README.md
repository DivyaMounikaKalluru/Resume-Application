# MyApplicantApp

This is a Model Application used for ITSC DevOps Internship - Fall 2020.

## Build the project

Run `ng serve` for a dev server. Navigate to `http://localhost:4200/`. The app will automatically reload if you change any of the source files.

## Run the Server

Go to the database-working folder.

Run `node server2.js`.

## Author

Rohit Pillutla Venkata Sathya
