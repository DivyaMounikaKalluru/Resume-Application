export class Applicant {
    constructor(
      public firstName: string,
      public lastName: string,
      public eMail: string,
      public position: string,
    ) {}
  }