export class Jobs {
    constructor(
        public role: string

    ) {}
}